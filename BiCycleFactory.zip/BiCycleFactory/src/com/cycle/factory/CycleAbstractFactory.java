package com.cycle.factory;

public interface CycleAbstractFactory {
	
	public Cycle createCyle();

}
