package com.cycle.factory;

public interface Cycle {
	
	   public String cycleType();
	   
	   public String cycleDescription();
	   
	   public Integer getCyclePrice();

}
